import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 80)
                .fill(.yellow)
                .frame(width: 180, height: 220)
            
            Rectangle()
                .fill(.brown)
                .frame(width: 190, height: 60)
                .offset(y: -90)
            
            Circle()
                .fill(.white)
                .frame(width: 40, height: 40)
                .offset(x: -40, y: -30)
            
            Circle()
                .fill(.white)
                .frame(width: 40, height: 40)
                .offset(x: 40, y: -30)
            
            Circle()
                .fill(.black)
                .frame(width: 15, height: 15)
                .offset(x: -40, y: -30)
            
            Circle()
                .fill(.black)
                .frame(width: 15, height: 15)
                .offset(x: 40, y: -30)
            
            Circle()
                .trim(from: 0.6, to: 0.9)
                .stroke(style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .frame(width: 100, height: 100)
                .rotationEffect(.degrees(180))
                .offset(y: 40)
        }
    }
}

#Preview {
    ContentView()
}

