import SwiftUI
import Combine

struct Obstacle: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var width: CGFloat
    var height: CGFloat
    var speed: CGFloat
}

struct ContentView: View {
    @State private var level = 1
    @State private var time = 20
    @State private var initialTime = 20
    @State private var frogX: CGFloat = 60
    private let frogSize: CGFloat = 36
    @State private var obstacles: [Obstacle] = []
    @State private var spawnTick = 0
    @State private var isRunning = false
    @State private var showLevelUp = false
    @State private var message: String? = nil
    let tick = Timer.publish(every: 0.03, on: .main, in: .common).autoconnect()
    @State private var accumulated = 0.0
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Circle().stroke(lineWidth: 8).foregroundStyle(.secondary).padding(20)
                Rectangle()
                    .fill(Color.green.opacity(0.25))
                    .frame(width: 24)
                    .position(x: geo.size.width - 24, y: geo.size.height / 2)
                    .overlay(Text("GOAL →").font(.caption.bold()).rotationEffect(.degrees(90)).offset(x: -6))
                Circle()
                    .fill(.green)
                    .frame(width: frogSize, height: frogSize)
                    .position(x: frogX, y: geo.size.height * 0.8)
                    .overlay(Text("🐸").font(.system(size: frogSize * 0.8)))
                ForEach(obstacles) { o in
                    Rectangle()
                        .fill(.red)
                        .frame(width: o.width, height: o.height)
                        .position(x: o.x, y: o.y)
                }
                VStack(spacing: 8) {
                    HStack {
                        Text("Level \(level)").font(.title3.bold())
                        Spacer()
                        Text("⏱️ \(time)s").font(.title3.monospacedDigit())
                    }
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 8).fill(Color.gray.opacity(0.2)).frame(height: 12)
                        let ratio = max(0, CGFloat(time) / CGFloat(max(initialTime, 1)))
                        RoundedRectangle(cornerRadius: 8).fill(.blue).frame(width: 240 * ratio, height: 12).animation(.linear(duration: 0.28), value: time)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding()
                .frame(maxHeight: .infinity, alignment: .top)
                if let msg = message {
                    Text(msg).font(.title2.bold()).padding(.horizontal, 16).padding(.vertical, 8).background(Color.black.opacity(0.1)).clipShape(Capsule()).shadow(radius: 8)
                }
                if showLevelUp {
                    Text("Level Up!").font(.title2.bold()).padding(.horizontal, 16).padding(.vertical, 8).background(Color.black.opacity(0.1)).clipShape(Capsule()).shadow(radius: 8)
                }
                VStack {
                    Spacer()
                    HStack(spacing: 12) {
                        Button("◀︎ Left") { moveFrog(dx: -24, maxWidth: geo.size.width) }.buttonStyle(.borderedProminent)
                        Button(isRunning ? "Pause" : "Start") {
                            if !isRunning && time <= 0 { startLevel() }
                            isRunning.toggle()
                        }.buttonStyle(.bordered)
                        Button("Right ▶︎") { moveFrog(dx: 24, maxWidth: geo.size.width) }.buttonStyle(.borderedProminent)
                    }
                    .padding(.bottom, 20)
                }
            }
            .background(Color.black.opacity(0.02))
            .onAppear { startLevel() }
            .onReceive(tick) { _ in
                guard isRunning else { return }
                gameTick(size: geo.size)
                accumulated += 0.03
                if accumulated >= 1.0 {
                    accumulated = 0.0
                    if time > 0 { time -= 1 }
                    if time == 0 { overflowReset() }
                }
            }
        }
    }
    
    func initialTimeForLevel(_ level: Int) -> Int {
        if level == 1 { return 20 }
        else if level == 2 { return 18 }
        else if level == 3 { return 16 }
        else if level == 4 { return 14 }
        else { return 8 }
    }
    
    func startLevel() {
        initialTime = initialTimeForLevel(level)
        time = initialTime
        obstacles.removeAll()
        spawnTick = 0
        message = "Level \(level)"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { message = nil }
        isRunning = true
        frogX = 60
    }
    
    func nextLevel() {
        isRunning = false
        level += 1
        showLevelUp = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            showLevelUp = false
            startLevel()
        }
    }
    
    func overflowReset() {
        isRunning = false
        message = "TIME UP! Restarting…"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            message = nil
            startLevel()
        }
    }
    
    func hitReset() {
        isRunning = false
        message = "💥 Ouch! Resetting…"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            message = nil
            startLevel()
        }
    }
    
    func gameTick(size: CGSize) {
        spawnTick += 1
        if spawnTick % max(30 - level * 2, 8) == 0 {
            spawnObstacle(width: size.width)
        }
        if !obstacles.isEmpty {
            for i in obstacles.indices { obstacles[i].y += obstacles[i].speed }
        }
        obstacles.removeAll { $0.y - $0.height/2 > size.height + 40 }
        if intersectsAnyObstacle(center: CGPoint(x: frogX, y: size.height * 0.8), radius: frogSize / 2) {
            hitReset()
            return
        }
        let goalX = size.width - 24 - 8
        if frogX + frogSize/2 >= goalX { nextLevel() }
    }
    
    func spawnObstacle(width: CGFloat) {
        let w = CGFloat(Int.random(in: 40...120))
        let h = CGFloat(Int.random(in: 16...28))
        let x = CGFloat.random(in: 24...(width - 24))
        let speed = CGFloat.random(in: 2.0...4.5) + CGFloat(level) * 0.3
        obstacles.append(Obstacle(x: x, y: -h, width: w, height: h, speed: speed))
    }
    
    func moveFrog(dx: CGFloat, maxWidth: CGFloat) {
        let left = frogSize/2 + 8
        let right = maxWidth - 8
        withAnimation(.easeOut(duration: 0.12)) { frogX = min(max(frogX + dx, left), right) }
    }
    
    func intersectsAnyObstacle(center: CGPoint, radius: CGFloat) -> Bool {
        for o in obstacles {
            let rect = CGRect(x: o.x - o.width/2, y: o.y - o.height/2, width: o.width, height: o.height)
            let cx = min(max(center.x, rect.minX), rect.maxX)
            let cy = min(max(center.y, rect.minY), rect.maxY)
            let dx = center.x - cx
            let dy = center.y - cy
            if dx*dx + dy*dy <= radius*radius { return true }
        }
        return false
    }
}

