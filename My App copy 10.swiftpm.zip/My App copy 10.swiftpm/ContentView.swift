import SwiftUI

struct TicTacToeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    // 3x3 board as 9 strings: "", "X", or "O"
    @State private var board: [String] = Array(repeating: "", count: 9)
    @State private var currentPlayer: String = "X"
    @State private var winner: String? = nil
    @State private var moves: Int = 0
    
    // All winning index triplets
    private let wins: [[Int]] = [
        [0,1,2],[3,4,5],[6,7,8], // rows
        [0,3,6],[1,4,7],[2,5,8], // cols
        [0,4,8],[2,4,6]          // diagonals
    ]
    
    var body: some View {
        VStack(spacing: 16) {
            Text(statusText)
                .font(.title2).bold()
            
            // 3x3 grid
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 3), spacing: 8) {
                ForEach(0..<9) { i in
                    CellView(symbol: board[i])
                        .onTapGesture { tap(i) }
                }
            }
            .padding(.horizontal, 24)
            
            HStack(spacing: 12) {
                Button("Reset") { reset() }
                    .buttonStyle(.borderedProminent)
                Button("Swap First Player") {
                    // only when game not started or after reset
                    guard moves == 0 else { return }
                    currentPlayer = (currentPlayer == "X") ? "O" : "X"
                }
                .buttonStyle(.bordered)
                .disabled(moves != 0)
            }
        }
        .padding()
    }
    
    private var statusText: String {
        if let w = winner { return w == "Draw" ? "Draw!" : "\(w) wins!" }
        return "Turn: \(currentPlayer)"
    }
    
    private func tap(_ i: Int) {
        // ignore taps if cell filled or game finished
        guard board[i].isEmpty, winner == nil else { return }
        board[i] = currentPlayer
        moves += 1
        checkForWinner()
        if winner == nil { currentPlayer = (currentPlayer == "X") ? "O" : "X" }
    }
    
    private func checkForWinner() {
        for line in wins {
            let a = board[line[0]], b = board[line[1]], c = board[line[2]]
            if !a.isEmpty, a == b, b == c {
                winner = a
                return
            }
        }
        if moves == 9 { winner = "Draw" }
    }
    
    private func reset() {
        board = Array(repeating: "", count: 9)
        winner = nil
        moves = 0
        currentPlayer = "X"
    }
}

struct CellView: View {
    let symbol: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(white: 0.95))
                .frame(height: 100)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(.gray.opacity(0.4), lineWidth: 1)
                )
            Text(symbol)
                .font(.system(size: 48, weight: .bold, design: .rounded))
                .foregroundColor(.primary)
        }
    }
}

