import SwiftUI

struct ContentView: View {
    @State private var id = 0
    @State private var overflow = false
    
    var binary: [Int] {
        let bits = String(id, radix: 2)
        let padded = String(repeating: "0", count: 4 - bits.count) + bits
        return padded.map { Int(String($0))! }
    }
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Decimal: \(id)")
                .font(.title)
            
            Text("Binary: \(String(id, radix: 2).padding(toLength: 4, withPad: "0", startingAt: 0))")
                .font(.title2)
                .monospaced()
            
            HStack {
                ForEach(binary.indices, id: \.self) { i in
                    Rectangle()
                        .fill(binary[i] == 1 ? .green : .gray)
                        .frame(width: 50, height: 50)
                        .cornerRadius(8)
                }
            }
            
            if overflow {
                Text("OVERFLOW!")
                    .foregroundColor(.red)
                    .bold()
            }
            
            HStack {
                Button("Enroll (+1)") {
                    id = (id + 1) % 16
                    overflow = (id == 0)
                }
                .buttonStyle(.borderedProminent)
                
                Button("Reset (0)") {
                    id = 0
                    overflow = false
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
    }
}

