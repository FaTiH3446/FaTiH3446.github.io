func hotChocolateMachine() {
    var startTemp = 20
    var temp = startTemp
    
    for minute in 1...20 {
        temp += 5
        print("Minute \(minute): \(temp)°C")
        
        if temp < 50 {
            print("→ The drink is still cold.")
        } else if temp <= 70 {
            print("→ The drink is ready to serve!")
        } else if temp <= 80 {
            print("→ Too hot! Wait before drinking.")
        } else {
            print("⚠ Machine auto-stop activated!")
            break
        }
    }
    
    print("Total temperature change: \(temp - startTemp)°C")
}

hotChocolateMachine()

